# Architecture — V1

## Overview

V1 is intentionally limited to the RAG foundation. The application layer does not yet exist; the Knowledge Base is queried through the Amazon Bedrock console for validation.

## Logical architecture

```text
+----------------------+
| Study document       |
| PDF                  |
+----------+-----------+
           |
           v
+----------------------+
| Amazon S3            |
| Document source      |
+----------+-----------+
           |
           v
+----------------------------------+
| Amazon Bedrock Knowledge Base    |
|                                  |
| Managed parser                   |
| Default chunking                 |
| Managed vector storage           |
+----------------+-----------------+
                 |
        +--------+--------+
        |                 |
        v                 v
+---------------+   +----------------------+
| Titan Text    |   | Semantic retrieval   |
| Embeddings V2 |   | from vector store    |
+---------------+   +----------+-----------+
                               |
                               v
                    +----------------------+
                    | Retrieved context    |
                    +----------+-----------+
                               |
                               v
                    +----------------------+
                    | Amazon Nova Micro    |
                    | Response generation  |
                    +----------+-----------+
                               |
                               v
                    +----------------------+
                    | Answer + source      |
                    | fragments            |
                    +----------------------+
```

## Components

### Amazon S3

The document source for the Knowledge Base. The V1 environment uses an S3 bucket containing the study document(s).

### Amazon Bedrock Knowledge Base

Provides the managed RAG workflow. It connects the S3 source to ingestion, vectorization, retrieval and generation capabilities.

### Titan Text Embeddings V2

Used as the embedding model in V1. Its purpose is retrieval, not response generation.

### Managed vector storage

Stores the vector representations required for semantic search without requiring a separately managed vector database in V1.

### Amazon Nova Micro

Used by the console test as the generation model. It receives the query and retrieved context and produces the answer.

## Request flow

```text
1. User submits a question
2. Knowledge Base receives the query
3. Relevant document chunks are retrieved
4. Retrieved context is passed to the generation model
5. Model generates an answer
6. Source fragments are exposed in the test interface
```

## Security considerations in V1

The S3 bucket is not intended to be public. Access is provided through AWS service permissions.

A dedicated Bedrock service role was created for the Knowledge Base instead of using an administrator permission set for the resource itself.

Secrets and credentials are not required in the public repository.

## Future architecture

The target application architecture is:

```text
                    +----------------+
                    | Web Frontend   |
                    +-------+--------+
                            |
                            v
                    +----------------+
                    | API Gateway    |
                    +-------+--------+
                            |
                            v
                    +----------------+
                    | AWS Lambda     |
                    +-------+--------+
                            |
                 +----------+----------+
                 |                     |
                 v                     v
       +------------------+   +------------------+
       | Bedrock KB       |   | DynamoDB         |
       | RAG              |   | conversation     |
       +------------------+   | history          |
                              +------------------+
```

Later versions will add Guardrails, evaluation and Terraform-managed infrastructure.
