# Development Log

## 2026-08-25 — V1: RAG proof of concept

### Goal

Validate the core Retrieval-Augmented Generation workflow for the AWS AI Study Assistant before implementing the application API and frontend.

### Implemented

- Created an Amazon S3 bucket for study documents.
- Uploaded an initial study document in PDF format.
- Created an Amazon Bedrock Managed Knowledge Base.
- Configured managed vector storage.
- Configured managed embeddings with Amazon Titan Text Embeddings V2.
- Created a Bedrock execution/service role for the Knowledge Base.
- Added an Amazon S3 data source.
- Used the managed parser.
- Used the default text chunking strategy.
- Synchronized the S3 data source successfully.
- Tested the Knowledge Base through the Bedrock console.
- Confirmed that the response displayed retrieved source fragments from the indexed document.
- Confirmed that the RAG pipeline could answer questions using the indexed study material.

### Validation result

**V1: PASS**

The document-to-RAG pipeline is operational.

### Observed architecture

```text
S3
  -> Bedrock Knowledge Base
  -> parsing/chunking
  -> embeddings
  -> managed vector storage
  -> retrieval
  -> Nova Micro
  -> answer + source fragments
```

### Notes

During initial setup, an S3 data source was created with an invalid configuration and failed validation. A correctly configured S3 data source was subsequently created using the bucket `ai-study-aws-aif`, and synchronization completed successfully.

The final public documentation intentionally does not include the AWS account identifier, resource ARNs, or other account-specific metadata.

### What was learned

- A Knowledge Base is not the same thing as a foundation model.
- Embeddings are used for semantic retrieval, while a foundation model generates the final response.
- RAG adds external context to generation rather than retraining the model.
- S3 can act as the document source for a managed Bedrock Knowledge Base.
- Source fragments are valuable for grounding and traceability.
- IAM roles connect AWS services without placing long-lived credentials inside application code.

### Next milestone

Build the first application backend:

```text
API Gateway
    -> Lambda
        -> Bedrock Knowledge Base
            -> response + citations
```

### Future evaluation plan

The project will later compare retrieval and answer quality with different configurations and measure failure modes such as hallucination, poor retrieval, prompt injection and unsupported answers.
