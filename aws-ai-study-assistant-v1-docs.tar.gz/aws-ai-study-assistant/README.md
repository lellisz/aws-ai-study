# AWS AI Study Assistant

> An AWS-native study assistant built to validate and demonstrate practical knowledge in Generative AI, RAG, and serverless architecture.

## Project status

**Current version: V1 — RAG proof of concept ✅**

The first version validates the complete document-to-retrieval pipeline using Amazon S3 and an Amazon Bedrock Knowledge Base. A PDF study document was uploaded to S3, ingested successfully, and queried through the Bedrock Knowledge Base test interface with source fragments returned alongside the generated answer.

### V1 status

- ✅ Amazon S3 document storage
- ✅ Amazon Bedrock Managed Knowledge Base
- ✅ Managed vector storage
- ✅ Managed embeddings using Amazon Titan Text Embeddings V2
- ✅ S3 data source configured
- ✅ Managed document parsing
- ✅ Default text chunking
- ✅ Successful data synchronization / ingestion
- ✅ RAG query tested successfully
- ✅ Retrieved source fragments observed in the response
- ⬜ AWS Lambda API
- ⬜ Amazon API Gateway
- ⬜ Web frontend
- ⬜ Conversation history with DynamoDB
- ⬜ Amazon Bedrock Guardrails
- ⬜ Automated evaluation pipeline
- ⬜ Terraform / Infrastructure as Code
- ⬜ CI/CD

## 1. Problem

Study materials are usually stored as large documents, making it difficult to ask focused questions and quickly locate the supporting content.

The goal of this project is to build a study assistant that can answer questions grounded in a user's documents instead of relying exclusively on the foundation model's internal knowledge.

## 2. Objective

Build a production-oriented study assistant that progressively demonstrates:

1. Document ingestion and storage
2. Retrieval-Augmented Generation (RAG)
3. Source attribution
4. Serverless application architecture
5. Security controls
6. Evaluation and observability
7. Infrastructure as Code and deployment automation

The project is intentionally being developed incrementally. V1 focuses only on proving that the RAG foundation works before adding application and infrastructure complexity.

## 3. V1 architecture

```text
                    Study document (PDF)
                            |
                            v
                     Amazon S3
                            |
                            v
              Bedrock Knowledge Base
                            |
                 +----------+----------+
                 |                     |
                 v                     v
        Text parsing/chunking      Embeddings
                 |             Titan Text Embeddings V2
                 |                     |
                 +----------+----------+
                            |
                            v
                   Managed vector store
                            |
                            v
                       User query
                            |
                            v
                 Retrieve relevant chunks
                            |
                            v
                    Foundation model
                    (Nova Micro)
                            |
                            v
                  Answer + source data
```

## 4. AWS services used in V1

| Service | Role in the project |
|---|---|
| **Amazon S3** | Stores the study documents used as the knowledge source. |
| **Amazon Bedrock Knowledge Bases** | Manages ingestion, retrieval and the RAG workflow for the document corpus. |
| **Amazon Titan Text Embeddings V2** | Converts document content into vector embeddings used for semantic retrieval. |
| **Amazon Nova Micro** | Generates the final answer from the retrieved context during the console test. |
| **AWS IAM** | Provides the Bedrock service role needed to access the configured AWS resources. |
| **Amazon CloudWatch Logs** | Application log delivery was configured for the Knowledge Base. |

## 5. How the V1 RAG flow works

### Step 1 — Store the document

A study PDF was uploaded to an S3 bucket.

### Step 2 — Create the Knowledge Base

A Managed Knowledge Base was created with managed vector storage and managed embeddings.

### Step 3 — Ingest the source

The S3 data source was synchronized successfully. Bedrock processed the document using the configured managed parser and the default chunking strategy.

### Step 4 — Generate embeddings

The document content is represented as vectors using Titan Text Embeddings V2.

### Step 5 — Retrieve relevant context

When a question is submitted, the Knowledge Base searches for semantically relevant chunks from the indexed document.

### Step 6 — Generate the answer

The retrieved context is provided to the selected foundation model, which produces the final answer.

### Step 7 — Inspect the source

The Bedrock test interface exposed the retrieved source fragments associated with the generated response. This is the key V1 validation that the system is grounded in the indexed document.

## 6. V1 validation

The ingestion pipeline completed successfully and the Knowledge Base was tested with questions related to the uploaded study material.

During testing, the console displayed source fragments containing content from the indexed document, including references to topics such as Machine Learning, Deep Learning, Generative AI, Amazon Bedrock, Amazon SageMaker AI and IAM.

This validates the core hypothesis of the project:

> A document stored in S3 can be indexed by Bedrock Knowledge Bases and used as retrieved context for grounded generative responses.

## 7. Design decisions

### Why a Managed Knowledge Base?

V1 deliberately uses the managed Bedrock experience instead of manually building an embedding pipeline and vector database. This keeps the first milestone focused on understanding the RAG workflow and AWS service integration.

### Why managed embeddings?

The project does not need custom embedding infrastructure at this stage. Managed embeddings reduce operational complexity while still allowing us to demonstrate semantic retrieval.

### Why default chunking?

Chunking will be studied and tuned later as part of the evaluation phase. Using the default strategy in V1 provides a stable baseline for future experiments.

### Why S3?

S3 is a simple and natural document source for the first version, and it allows the project to scale from a single test document to an organized study corpus later.

## 8. Current limitations

V1 is a proof of concept and is not yet a complete application.

Current limitations include:

- No public-facing application interface
- No API layer
- No authentication or user management
- No conversation history
- No automated guardrails
- No automated evaluation dataset
- No infrastructure-as-code deployment
- No CI/CD pipeline

These are intentional and will be addressed incrementally in later versions.

## 9. Roadmap

### V2 — Serverless API

```text
Client -> API Gateway -> Lambda -> Bedrock Knowledge Base
```

### V3 — Web application

Add a simple web interface for document questions and source display.

### V4 — Persistence

Add DynamoDB for conversations, sessions and query history.

### V5 — Responsible AI / security

Add Bedrock Guardrails and tests for prompt injection, unsafe content and other failure modes.

### V6 — Evaluation

Create a benchmark dataset and measure retrieval quality, answer quality, groundedness and failure cases.

### V7 — Infrastructure as Code

Rebuild the environment using Terraform and make the project reproducible.

### V8 — CI/CD

Add automated testing and deployment through GitHub Actions.

## 10. Portfolio value

The project is designed to demonstrate practical understanding of:

- Foundation Models
- Embeddings
- Vector search
- Retrieval-Augmented Generation (RAG)
- Grounded generation and source attribution
- Amazon Bedrock
- Amazon S3
- IAM
- Serverless architecture
- Observability
- Responsible AI
- Evaluation of GenAI applications

## 11. Development log

See [`docs/development-log.md`](docs/development-log.md).

## 12. Architecture notes

See [`docs/architecture.md`](docs/architecture.md).

## Disclaimer

This repository documents the technical development of the project. Any documents used for experiments should be owned by the project author, publicly licensed, or otherwise authorized for use. Do not publish private study materials, credentials, API keys, account identifiers, or other sensitive information.
